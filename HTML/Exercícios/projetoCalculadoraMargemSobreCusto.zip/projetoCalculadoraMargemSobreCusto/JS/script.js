function conta(){
    let produto = document.getElementById("produto").value;
    let markUp = document.getElementById("markUp").value/100;

    console.log(produto);
    console.log(typeof produto);
    console.log(markUp);
    console.log(typeof markUp);
    console.log(typeof produto == Number)
    
    if(produto != "" && markUp != ""){
        let custoComMarkUp = produto * (1+markUp);
        let precoVenda = custoComMarkUp / (1 - 0.18 - 0.0925);
        let ICMS = precoVenda * 0.18;
        let PIS_COF = precoVenda * 0.0925;
        let IPI = precoVenda * (1+0.15);
        let margemLucro = custoComMarkUp - produto;
        let margemLucroPorcentagem = margemLucro / precoVenda;

        document.getElementById("custoComMarkUp").value = custoComMarkUp.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("precoVenda").value = precoVenda.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("ICMS").value = ICMS.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("PIS_COF").value = PIS_COF.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("IPI").value = IPI.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("margemLucro").value = margemLucro.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'});
        document.getElementById("margemLucroPorcentagem").value = (margemLucroPorcentagem.toFixed(4) * 100) + "%";
    }
    else{
        alert("Digite os valores para prosseguir!");
    }
}